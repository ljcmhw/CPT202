package com.CPT202.PetGroomingSystem.MS.GF.Controllers;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.ui.ExtendedModelMap;
import org.springframework.ui.Model;

import static org.junit.jupiter.api.Assertions.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;

@ExtendWith(SpringExtension.class)
@SpringBootTest
@AutoConfigureMockMvc
class GroomerControllerIntegrationTest {

    @Autowired
    private MockMvc mockMvc;

    /*
    blackBox testing without model input
     */
    @Test
    void addGroomerIntegrationTest() throws Exception {
        mockMvc.perform(get("/Groomer/add"))
                .andExpect(status().isOk())
                .andExpect(view().name("admin/AddGroomer"))
                .andExpect(model().attributeExists("groomer"));
    }

    /*
    white box testing
    passing a model as param
     */
    @Test
    public void testAddGroomerWhiteBox() {
        Model model = new ExtendedModelMap();
        String viewName = new GroomerController().addGroomer(model);
        assertEquals("admin/AddGroomer", viewName);
        assertTrue(model.containsAttribute("groomer"));
    }

//    @Test
//    void addGroomerIntegrationTestBadRequest() throws Exception {
//        mockMvc.perform(get("/Groomer/add1"))
//                .andExpect(status().is4xxClientError())
//                .andExpect(view().name("admin/AddGroomer"))
//                .andExpect(model().attributeExists("groomer"));
//    }



    @Test
    void confirmNewGroomer() {
    }

    @Test
    void editGroomer() {
    }

    @Test
    void updateGroomer() {
    }

    @Test
    void deleteGroomer() {
    }
}