package com.CPT202.PetGroomingSystem.MS.US.Controllers;

import com.CPT202.PetGroomingSystem.MS.US.Repo.ServceRepo;
import com.CPT202.PetGroomingSystem.MS.US.Services.ServceService;
import com.CPT202.PetGroomingSystem.MS.US.models.Servce;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

@ExtendWith(SpringExtension.class)
@SpringBootTest
@AutoConfigureMockMvc
class ServceControllerIntegrationTest {
    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ServceRepo serviceRepo;

    @Autowired
    private ServceService servceService;

//    @Test
//    void confirmNewServceIntegrationTest() throws Exception {
//
//        //Servce servce = new Servce(1, "Test Service", "Test Info", 10.0f);
//        Servce servce = new Servce();
//        servce.setId(1);
//        servce.setName("Test Service");
//        servce.setInfo("Test Info");
//        servce.setPrice(10.0f);
//
//        Mockito.when(servceService.newService(Mockito.any(Servce.class))).thenReturn(servce);
//
//        mockMvc.perform(post("/Service/add")
//                        .contentType(MediaType.APPLICATION_FORM_URLENCODED)
//                        .param("name", "Test Service")
//                        .param("info", "Test Info")
//                        .param("price", "10.0"))
//                .andExpect(status().isOk())
//                .andExpect(view().name("admin/BackMaintainPage"));
//    }


    @Test
    void addServceIntegrationTestGet() throws Exception {
        Servce servce = new Servce(1, "Test Service", "Test Info", 10.0f);

        mockMvc.perform(get("/Service/add"))
                .andExpect(status().isOk())
                .andExpect(view().name("admin/AddServce"))
                .andExpect(model().attributeExists("servce"));
               // .andExpect(model().attribute("servce", servce));
    }



    @Test
    void editServce() {
    }

    @Test
    void updateServce() {
    }
}