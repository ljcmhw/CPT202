package com.CPT202.PetGroomingSystem.MS.US.Services;

import com.CPT202.PetGroomingSystem.MS.US.Repo.ServceRepo;
import com.CPT202.PetGroomingSystem.MS.US.models.Servce;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
class ServceServiceUnitTest {

    @Mock
    private ServceRepo serviceRepo;
    @InjectMocks
    private ServceService provideService;

    @Test
    void newServiceCorrectedAdded() {
        //given
        Servce PetBath = new Servce(12, "Bath", "Bath Service Info", 13);

        //when
        provideService.newService(PetBath);

        //then
        //capture th argum passed to save()
        ArgumentCaptor<Servce> petServiceArgumentCaptor =
                ArgumentCaptor.forClass(Servce.class);
        //verify the save() is called with correct argu
        verify(serviceRepo).save(petServiceArgumentCaptor.capture());

        Servce capturedPetService = petServiceArgumentCaptor.getValue();

        assertEquals(capturedPetService, PetBath);
    }

    /*
    Test with Empty Name inputs
     */
    @Test
    public void testNewServiceWithEmptyName() {
        //given
        Servce emptyName = new Servce(1, "", "Service Info", 3);

        //when
        Servce result = provideService.newService(emptyName);

        //then
        //verify null is returned when input is invalid
        assertNull(result);
        //never() checks
        // the serviceRepo.save() is never called if input is invalid
        verify(serviceRepo, never()).save(any());
    }

    @Test
    public void testNewServiceWithEmptyInfo() {
        //given
        Servce emptyInfo = new Servce(3, "Brush Teeth", "", 1);

        //when
        Servce result = provideService.newService(emptyInfo);

        //then
        assertNull(result);
        verify(serviceRepo, never()).save(any());
    }

    @Test
    public void testNewServiceWithInvalidPrice() {
        //given
        Servce invalidPrice = new Servce(3, "Nail Trimming", "Trim nails for pets", 0);

        //when
        Servce result = provideService.newService(invalidPrice);

        //then
        assertNull(result);
        verify(serviceRepo, never()).save(any());
    }

    @Test
    public void testNewServiceWithAllInvalid() {
        //given
        Servce allInvalid = new Servce(19, "", "", 0);

        //when
        Servce result = provideService.newService(allInvalid);

        //then
        assertNull(result);
        verify(serviceRepo, never()).save(any());
    }




    @Test
    @Disabled
    void getList() {
    }

    @Test
    @Disabled
    void getDescList() {
    }

    @Test
    @Disabled
    void delServce() {
    }

    @Test
    @Disabled
    void findById() {
    }

    @Test
    void findByName() {
    }

    @Test
    @Disabled
    void getListByName() {
    }
}