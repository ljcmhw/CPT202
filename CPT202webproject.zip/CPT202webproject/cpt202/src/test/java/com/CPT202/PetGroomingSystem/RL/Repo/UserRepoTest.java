package com.CPT202.PetGroomingSystem.RL.Repo;

import com.CPT202.PetGroomingSystem.RL.models.User;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;

/*
Just Practice. No need to test the JpaRepository.
 */
@ExtendWith(MockitoExtension.class)
class UserRepoTest {

    @Mock
    private UserRepo TestingUserRepo;

    /*
    under Each test, delete all input.
     */
    @AfterEach
    void tearDown(){
        TestingUserRepo.deleteAll();
    }

    @Test
    void TestingCorrectFindByUserNameOrEmailAddress() {
        //given
        User user = new User("NewUser",
                "newUser@email",
                "179890",
                "password",
                true,
                "XJTLU",
                true,
                "customer"
                );
        TestingUserRepo.save(user);

        //when
        Mockito.when(TestingUserRepo.findByUserNameOrEmailAddress("NewUser", "newUser@email"))
                .thenReturn(Optional.of(user));
        Optional<User> expected
                = TestingUserRepo.findByUserNameOrEmailAddress("NewUser", "newUser@email");

        //then
        assertTrue(expected.isPresent());
        assertEquals(user.getUserName(), expected.get().getUserName());
        assertEquals(user.getEmailAddress(), expected.get().getEmailAddress());
    }

//    @Test
//    void TestingFindByIncorrectUserNameOrEmailAddress() {
//        //given
//        User user = new User("NewUser",
//                "newUser@email",
//                "179890",
//                "password",
//                true,
//                "XJTLU",
//                true,
//                "customer"
//        );
//        TestingUserRepo.save(user);
//
//        //when
//        //incorrect Input for Username
//        Mockito.when(TestingUserRepo.findByUserNameOrEmailAddress("User", "newUser@email"))
//                .thenReturn(Optional.of(user));
//        Optional<User> incorrectUserName
//                = TestingUserRepo.findByUserNameOrEmailAddress("User", "newUser@email");
//
//        //then
//        assertFalse(incorrectUserName.isPresent()); //incorrect user info input
//        assertNotEquals(user.getUserName(), incorrectUserName.get().getUserName());
//        assertNotEquals(user.getEmailAddress(), incorrectUserName.get().getEmailAddress());
//
//    }

    @Test
    public void testIncorrectUsername() {
        Optional<User> result = TestingUserRepo.findByUserNameOrEmailAddress("incorrectusername", "newUser@email");
        assertFalse(result.isPresent());
    }





}