package com.CPT202.PetGroomingSystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PetGroomingSystemApplicationTests {

	@Test
	void contextLoads() {
	}




}
