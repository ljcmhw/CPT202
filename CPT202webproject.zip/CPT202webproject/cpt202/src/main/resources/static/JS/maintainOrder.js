//filter by status
function filterOrdersByStatus() {
    var status = document.getElementById("status").value;
    var customer = document.getElementById("customer").value;
    // location.href = '/MaintainOrdersPage?status=' + status + '&customer=' + customer;
    var url = '/MaintainOrdersPage?';
    if (status) {
        url += 'status=' + status;
    }
    if (customer) {
        if (status) {
            url += '&';
        }
        url += 'customer=' + customer;
    }
    location.href = url;
}
//update status to In_progress by id
function Start(id) {
    location.href = '/MaintainOrdersPage/updateStatus?id=' + id + '&status=In_progress';
}
//update status to Completed by id
function Complete(id) {
    location.href = '/MaintainOrdersPage/updateStatus?id=' + id + '&status=Completed';
}
//cancel order by id
function Cancel(id) {
    if (confirm("Confirm Cancel ?") == true) {
        location.href = '/MaintainOrdersPage/cancel?id=' + id;
    }
}

function filterOrdersByCustomer() {
    var status = document.getElementById("status").value;
    var customer = document.getElementById("customer").value;
    // location.href = '/MaintainOrdersPage?status=' + status + '&customer=' + customer;
    var url = '/MaintainOrdersPage?';
    if (status) {
        url += 'status=' + status;
    }
    if (customer) {
        if (status) {
            url += '&';
        }
        url += 'customer=' + customer;
    }
    location.href = url;
}

