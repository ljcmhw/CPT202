function getAppTime(times) {
    var timeStr = "";
	for (i = 0; i < times.length; i++) {
	    times[i].onclick = function(e) {
	    	timeStr = this.innerText.split("-", 1);
	    	// alert(timeStr);
	        document.getElementById("timeStr").value = timeStr;
	        submitForm("timeForm");
	    }
	}
}

var times = document.getElementsByClassName("time");
getAppTime(times);