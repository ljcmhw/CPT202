var month_olympic = [31,29,31,30,31,30,31,31,30,31,30,31];
var month_normal = [31,28,31,30,31,30,31,31,30,31,30,31];
var available_time = ["9:00","9:30","10:00","10:30","11:00","11:30","14:00","14:30","15:00","15:30","16:00","16:30"]

var holder = document.getElementById("days");
var prev = document.getElementById("prev");
var next = document.getElementById("next");
var ctitle = document.getElementById("calendar-title");
var cyear = document.getElementById("calendar-year");
var ctime = document.getElementById("timetable")

var my_date = new Date();
var my_year = my_date.getFullYear();
var my_month = my_date.getMonth();
var my_day = my_date.getDate();


//获取某年某月第一天是星期几
function dayStart(month, year) {
	var tmpDate = new Date(year, month, 1);
	return (tmpDate.getDay());
}

//计算某年是不是闰年，通过求年份除以4的余数即可
function daysMonth(month, year) {
	if (year%4 === 0 && year%100 !== 0 || year%400 === 0) {
		return (month_olympic[month]);
	} else {
		return (month_normal[month]);
	}
}

function getAppDate(dates) {
    var dateStr = "";
	//var xhr = new XMLHttpRequest();
	//var url = "/SelectDateController/selectDate";

	//xhr.open("POST",url,true);

	for (i = 0; i < dates.length; i++) {
	    dates[i].onclick = function(e) {
	    	dateStr = my_year + "-" + (my_month+1) + "-" + this.innerText;
//	    	alert(dateStr);
	        document.getElementById("dateStr").value = dateStr;
	        //submitForm("dateFrom");
			//dateStr = "dateStr="+dateStr;
			//xhr.send(dateStr);
	    }
	}
}

function submitForm(formName) {
    document.getElementById(formName).submit();
}

function refreshDate() {
	var month_name = ["January","Febrary","March","April","May","June","July","Auguest",
                    "September","October","November","December"];
	var str = "";
	var totalDay = daysMonth(my_month, my_year); //获取该月总天数
	var firstDay = dayStart(my_month, my_year); //获取该月第一天是星期几
	var myclass;
	for(var i=1; i<firstDay; i++){
		str += "<li></li>"; //为起始日之前的日期创建空白节点
	}
	for(var i=1; i<=totalDay; i++){
		if ((i<my_day && my_year==my_date.getFullYear() && my_month==my_date.getMonth()) || my_year<my_date.getFullYear() || ( my_year==my_date.getFullYear() && my_month<my_date.getMonth())){
			myclass = " class='date lightgrey'"; //当该日期在今天之前时，以浅灰色字体显示
		} else if (i==my_day && my_year==my_date.getFullYear() && my_month==my_date.getMonth()){
			myclass = " class='date green greenbox'"; //当天日期以绿色背景突出显示
		} else {
			myclass = " class='date darkgrey'"; //当该日期在今天之后时，以深灰字体显示
		}
		str += "<li"+myclass+">"+i+"</li>"; //创建日期节点
	}
    holder.innerHTML = str; //设置日期显示
	ctitle.innerHTML = month_name[my_month]; //设置英文月份显示
	cyear.innerHTML = my_year; //设置年份显示
	var dates = document.getElementsByClassName("date");
	getAppDate(dates);
}
refreshDate();

prev.onclick = function(e) {
	e.preventDefault();
	my_month--;
	if (my_month<0) {
		my_year--;
		my_month = 11;
	}
	refreshDate();
}
next.onclick = function(e) {
	e.preventDefault();
	my_month++;
	if (my_month>11) {
		my_year++;
		my_month = 0;
	}
	refreshDate();
}

 function sendChosenTime(time){
    var timeStr = "";
	for (i = 0; i < time.length; i++) {
	    time[i].onclick = function(e) {
	    	timetr = time[i];
	    	// alert(dateStr);
	        document.getElementById("timeStr").value = timeStr;
	    }
	}
 }

function refreshTime(){
	var choosenTime = document.getElementById("TimeList");
	//alert(choosenTime);
	choosenTime = choosenTime.value;
	
	if(choosenTime=="")
		choosenTime="{}";
	choosenTime = JSON.parse(choosenTime);
	//alert(choosenTime);
	var str = "";
	var myclass;
	for(var i=0;i<12;i++){
		if(i%2==1){
			myclass = " class='time odd-time'";
		}else{
			myclass = " class='time even-time'";
		}
		for (var j in choosenTime){
			if (available_time[i]==choosenTime[j]){
				myclass = "class='timeInterval lightgrey'";
			}
		}
		if (document.getElementById("dateStr").value==""){
			myclass = "class='timeInterval lightgrey'";
		}
		str += "<li "+myclass+">"+available_time[i]+"</li>";
	}
	ctime.innerHTML = str;
	var time = document.getElementsByClassName("time");
	sendChosenTime(time);
}
refreshTime();
