package com.CPT202.PetGroomingSystem.MS.US.Controllers;

import com.CPT202.PetGroomingSystem.HomePage.Controller.rootController;
import com.CPT202.PetGroomingSystem.MS.US.Services.UpsellingService;
import com.CPT202.PetGroomingSystem.MS.US.models.Discount;
import com.CPT202.PetGroomingSystem.MS.US.models.Upselling;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.Date;

@Controller
@RequestMapping("/Upsell")
public class UpsellingController extends rootController {
    @Autowired
    private UpsellingService upsellingService;

    private boolean isHistory(Upselling d) {
        Date curDate = new Date();
        if (d.getTimelmt().compareTo(curDate) <= 0) return true;
        return false;
    }

    @GetMapping("/add")
    public String addUpsell(Model model) {
        model.addAttribute("upsell", new Upselling());
        return "admin/AddUpselling";
    }

    @PostMapping("/add")
    public String confirmNewUpsell(@ModelAttribute("upsell") Upselling s, Model model) {
        Upselling Up = upsellingService.newUpselling(s);
        if (Up == null) {
            if (isHistory(s))
                model.addAttribute("FieldEmptyErr", "The date must be after today.");
            else model.addAttribute("FieldEmptyErr", "Required field is empty, please fill in \n" +
                    "correct information");
            return addUpsell(model);
        }
        return backMaintainPage(model);
    }

    @RequestMapping(value = "/edit/{id}", method = RequestMethod.GET)
    public String editUpsell(@PathVariable String id, Model model) {
        Upselling oldUp = upsellingService.findById(Integer.valueOf(id));
        model.addAttribute("oldUp", oldUp);
        return "admin/EditUpselling";
    }

    @PostMapping("edit")
    public String updateUpsell(@ModelAttribute("oldUp") Upselling newUp, Model model) {
        Upselling Up = upsellingService.newUpselling(newUp);
        if (Up == null) {
            if (isHistory(newUp))
                model.addAttribute("FieldEmptyErr", "The date must be after today.");
            else model.addAttribute("FieldEmptyErr", "Required field is empty, please fill in \n" +
                    "correct information");
            return "admin/EditUpselling";
        }
        return backMaintainPage(model);
    }
}
