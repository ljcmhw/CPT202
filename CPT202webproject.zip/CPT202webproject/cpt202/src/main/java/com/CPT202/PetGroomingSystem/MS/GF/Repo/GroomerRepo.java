package com.CPT202.PetGroomingSystem.MS.GF.Repo;
import org.springframework.data.jpa.repository.JpaRepository;

import com.CPT202.PetGroomingSystem.MS.GF.models.Groomer;

public interface GroomerRepo extends JpaRepository<Groomer, Integer>{

    /*
     * check whether the system has duplicate name
     * @param name
     */

   // static boolean existsByName(String name) {
        // TODO Auto-generated method stub
        // //throw new UnsupportedOperationException("Unimplemented method 'existsByName'");
        // boolean existsByName(String Name);
    // }


}