package com.CPT202.PetGroomingSystem.PP.PI.Controllers;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.CPT202.PetGroomingSystem.PP.PI.Services.PetServices;
import com.CPT202.PetGroomingSystem.PP.PI.models.Pet;
import com.CPT202.PetGroomingSystem.RL.Repo.UserRepo;
import com.CPT202.PetGroomingSystem.RL.models.User;
import com.CPT202.PetGroomingSystem.RL.security.MyUserDetails;

@Controller
@RequestMapping("/pet")

public class PetInfoController {
    @Autowired
    private PetServices petService;

    @Autowired
    private UserRepo userRepo;
    @GetMapping("/list")
    public String getList(Model model){
        MyUserDetails userDetails = (MyUserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        int userId = userDetails.getId();
        List<Pet> userPetList = petService.getPetList(userId); // 使用getUserPetList()方法来获取用户特定的宠物列表
        model.addAttribute("petList", userPetList); // 将宠物列表添加到Model对象中
        return "user/allPets";
    }

    @GetMapping("/add")
    public String addPet(Model model){
        model.addAttribute("pet", new Pet());
        return "user/addPet";
    }
//create a pet
    @PostMapping("/add")
    public String confirmNewPet(@ModelAttribute("pet") Pet pet, Model model){
        MyUserDetails userDetails = (MyUserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        pet.setUserID(userDetails.getId());
        Optional<User> returneduser  = userRepo.findById(userDetails.getId());
        User user = returneduser.orElseThrow(() -> new UsernameNotFoundException("User not found"));
        //add the new team into database
        petService.newPet(pet);
        //model.addAttribute("petList", petService.getPetList());
        model.addAttribute("UserInformation", user);
        return "UserInformation";
    } 

    @GetMapping("/delete/{id}")
    public String deletePet(@PathVariable("id") String id) {
        petService.deletePet(Integer.valueOf(id));
        return "redirect:/pet/list";
    }

    @GetMapping("/edit/{id}")
    public String editPet(@PathVariable String id, Model model) {
        Optional<Pet> pet = petService.getPetById(Integer.valueOf(id));
        if (pet.isPresent()) {
            model.addAttribute("oldPet", pet.get());
            return "user/editPet";
        } else {
            // handle pet not found error
            return "redirect:/pet/list";
        }
    }

@PostMapping("/edit")
public String updatePet(@ModelAttribute("oldPet") Pet updatedPet, Model model) {
    petService.newPet(updatedPet);
    return "redirect:/pet/list";
}


    
}
