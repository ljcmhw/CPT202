package com.CPT202.PetGroomingSystem.RL.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.NoOpPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.util.matcher.AnyRequestMatcher;

@EnableWebSecurity
public class SecurityConfig extends WebSecurityConfigurerAdapter{

    static String ENCRYPTEDKEY="fhX2jlltyz";

    @Autowired
    private UserDetailsService userDetailsService;

    @Override
    protected void configure(AuthenticationManagerBuilder auth) throws Exception{
        auth.userDetailsService(userDetailsService);
    }

    @Override
    protected void configure(HttpSecurity http) throws Exception{
        http
            .formLogin()
            .loginPage("/LogIn.html")
            .loginProcessingUrl("/user/login")
            .defaultSuccessUrl("/user/login/success")
            .failureUrl("/user/login/failure")

            .and()
            .authorizeRequests()
            //.antMatchers("/user/login").hasRole(ENCRYPTEDKEY)
            //.antMatchers("/user/login").hasAnyRole(ENCRYPTEDKEY,"Customer")
            .antMatchers("/**").permitAll()
            .antMatchers("/user","/user/login","/user/registration").permitAll()
            .anyRequest().authenticated()
            
            .and()
            .csrf().disable();


        http.logout()
            .logoutUrl("/user/logout")
            .logoutSuccessUrl("/user/login").permitAll();
            
    }

    @Bean
    public PasswordEncoder getPasswordEncoder(){
        return NoOpPasswordEncoder.getInstance();//不加密
        //return new BCryptPasswordEncoder();
    }
}
