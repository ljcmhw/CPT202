package com.CPT202.PetGroomingSystem.MS.GF.Services;

import java.util.*;

// import javax.validation.Valid;

import com.CPT202.PetGroomingSystem.MS.US.models.Servce;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;

import com.CPT202.PetGroomingSystem.MS.GF.Repo.GroomerRepo;
import com.CPT202.PetGroomingSystem.MS.GF.models.Groomer;

@Service
public class GroomerService {
    
    @Autowired
    private GroomerRepo groomerRepo;


    /*
     * add groomer in database
     * @param All properties related to groomer
     */
    public Groomer newGroomer(Groomer g) {
        // if (customerRepo.existsByName(c.getCustomerName())){//not sure 
        //     Customer fake = new Customer(-8999, "fake", 9999, "fake", "fake");
        //     return fake;
        // }
        
        if (Objects.equals(g.getGroomerName(), "") ||
                Objects.equals(g.getPhoneNumber(), "") ||
                Objects.equals(g.getEmail(), "") ||
                g.getGroomerProService().isEmpty())
            return null;
        return groomerRepo.save(g);
    }

    /*
     * Groomer list to list all groomers in Maintain Groomer page
     * Ordered by created time
     */
    public List<Groomer> getGroomerList(){
        return groomerRepo.findAll();
    }

    // public Groomer editGroomer(int id, Groomer editG){
    //     Groomer oldGroomer = getGroomerById(id);


    // }

    /*
     * sort Groomer by alphabetical order of their name
     */
    public List<Groomer> getSortByName(){
    // public void getSortByName(){
        // List.sort(Comparator.comparing(Groomer::getGroomerName));
        Sort sortName = Sort.by(Sort.Direction.ASC, "groomerName");

        return groomerRepo.findAll(sortName);

    }
    
        
    /* 
     * find Specific groomer by their id
     * @param: id
     */
    public Groomer findById(int id) {
        List<Groomer> GroomerList = groomerRepo.findAll();
        for (Groomer i : GroomerList) {
            if (i.getId() == id) return i;
        }
        return null;
    }
   //@Override
    
    public Groomer getGroomerById(int id) {
        return groomerRepo.findById(id).orElseThrow(GroomerNotFoundException::new);
    }

    /*
     * Groomer is not found
     */
    public class GroomerNotFoundException extends RuntimeException {
    }

    // public void delGroome(Groomer g) {
    //     groomerRepo.delete(g);
    // }

    public void delGroomerById(int id) {
        groomerRepo.deleteById(id);
    }

    public Groomer findByName(String name) {
        List<Groomer> serList = groomerRepo.findAll();
        for (Groomer i : serList) {
            if (Objects.equals(i.getGroomerName(), name)) return i;
        }
        return null;
    }

    public List<Groomer> getListByName(List<String> names) {
        List<Groomer> groList = new ArrayList<>();
        for (String name: names) {
            Groomer gro = findByName(name);
            if (gro != null) groList.add(gro);
        }
        return groList;
    }
}
