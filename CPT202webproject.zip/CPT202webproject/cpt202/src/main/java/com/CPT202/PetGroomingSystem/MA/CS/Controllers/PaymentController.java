package com.CPT202.PetGroomingSystem.MA.CS.Controllers;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import com.CPT202.PetGroomingSystem.HomePage.Controller.rootController;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.CPT202.PetGroomingSystem.MS.US.Services.UpsellingService;
import com.CPT202.PetGroomingSystem.MS.US.models.Upselling;
import com.CPT202.PetGroomingSystem.RL.Repo.UserRepo;
import com.CPT202.PetGroomingSystem.RL.models.User;
import com.CPT202.PetGroomingSystem.RL.security.MyUserDetails;

@Controller
@RequestMapping("/Pay")
public class PaymentController extends MArootController {

    @Autowired
    private UpsellingService upsellingService;
    @Autowired
    private UserRepo userRepo;
    
    @GetMapping("/List")
    public String Listupselling(@ModelAttribute("dateStr") String dateStr, @ModelAttribute("timeStr") String timeStr,Model model){
        model.addAttribute("Upsellings", upsellingService.getDescList());
        MArootController.setDateStr(dateStr);
        MArootController.setTimeStr(timeStr);
        return "user/PaymentPage";
    }

    @RequestMapping(value="/upsellingList",method=RequestMethod.POST)
    public String choosedupselling(@RequestParam(value="upsellings", required=false)String Upselling,Model model) throws ParseException{
        List<String> upsellingNames = new ArrayList<>();
        int index = 0;
        MyUserDetails userDetails = (MyUserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Optional <User> returneduser = userRepo.findById(userDetails.getId());
        User user = returneduser.orElseThrow();
        if(Upselling!=null){
            for(String ups: Upselling.split(",")){
                upsellingNames.add(index, ups);
                index++;
            }
        }
        List<Upselling> upsList = upsellingService.getListByInfo(upsellingNames);
        String time = MArootController.getDateStr()+" "+MArootController.getTimeStr();
        
        return SubmitOrder(user, model, MArootController.getPetList(), MArootController.getDisList() ,MArootController.getSerList(), MArootController.getGroList(), upsList,time);
    
    }
}
