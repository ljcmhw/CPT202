package com.CPT202.PetGroomingSystem.MS.US.Services;

import com.CPT202.PetGroomingSystem.MS.US.Controllers.DiscountController;
import com.CPT202.PetGroomingSystem.MS.US.Repo.DiscountRepo;
import com.CPT202.PetGroomingSystem.MS.US.models.Discount;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Objects;


@Service
public class DiscountService {
    @Autowired
    private DiscountRepo discountRepo;

    private List<Discount> checkDate(List<Discount> lst) {
        Date curDate = new Date();
        for (Discount i : lst) {
            if (i.getTimelmt().compareTo(curDate) < 0) {
                discountRepo.deleteById(i.getId());
            }
        }
        lst = discountRepo.findAll();
        return lst;
    }

    public Discount newDiscount(Discount d) {
        if (Objects.equals(d.getCond(), "") || Objects.equals(d.getInfo(), ""))
            return null;
        Date curDate = new Date();
        if (d.getTimelmt().compareTo(curDate) <= 0) return null;
        return discountRepo.save(d);
    }

    public List<Discount> getList() {
        List<Discount> lst = discountRepo.findAll();
        return checkDate(lst);
    }
    public List<Discount> getDescList() {
        Sort sort = Sort.by(Sort.Direction.DESC, "id");
        List<Discount> lst = discountRepo.findAll(sort);
        return checkDate(lst);
    }

    public void delDiscount(Discount d) {
        discountRepo.delete(d);
    }
    public Discount findById(int id) {
        List<Discount> DisList = discountRepo.findAll();
        for (Discount i : DisList) {
            if (i.getId() == id) return i;
        }
        return null;
    }
    public Discount findByInfo(String info) {
        List<Discount> disList = discountRepo.findAll();
        for (Discount i : disList) {
            if (Objects.equals(i.getInfo(), info)) return i;
        }
        return null;
    }
    public List<Discount> getListByInfo(List<String> info) {
        List<Discount> disList = new ArrayList<>();
        for (String inform: info) {
            Discount dis = findByInfo(inform);
            if (dis != null) disList.add(dis);
        }
        return disList;
    }
}
