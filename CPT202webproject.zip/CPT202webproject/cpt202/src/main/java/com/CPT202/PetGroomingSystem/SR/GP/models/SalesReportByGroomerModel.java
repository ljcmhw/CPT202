package com.CPT202.PetGroomingSystem.SR.GP.models;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
@Entity
public class SalesReportByGroomerModel {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    private String groomerName;
    private int servicesQuantity;

    public String getGroomerName() {
        return groomerName;
    }

    public void setGroomerName(String groomerName) {
        this.groomerName = groomerName;
    }

    public int getServicesQuantity() {
        return servicesQuantity;
    }

    public void setServicesQuantity(int servicesQuantity) {
        this.servicesQuantity = servicesQuantity;
    }

    public SalesReportByGroomerModel(int id, String groomerName, int servicesQuantity) {
        this.id = id;
        this.groomerName = groomerName;
        this.servicesQuantity = servicesQuantity;
    }

    public SalesReportByGroomerModel(String groomerName, int servicesQuantity) {
        this.groomerName = groomerName;
        this.servicesQuantity = servicesQuantity;
    }

    public SalesReportByGroomerModel() {
    }
}
