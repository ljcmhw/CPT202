package com.CPT202.PetGroomingSystem.SR.SP.Controllers;

import com.CPT202.PetGroomingSystem.SR.SP.Services.SalesByServicesService;
import com.CPT202.PetGroomingSystem.SR.SP.models.SalesByServicesModel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;


import java.util.List;

@Controller
@RequestMapping("/MaintainSalesReportPage")
public class SalesByServicesController {
        @Autowired
        private SalesByServicesService salesByServicesService;
       /* @GetMapping("")
        public String getSalesReportPage() {
            return "admin/MaintainSalesReportPage";
        }*/
        @GetMapping("/byServices")
        public String getSalesByServices(Model model) {
        List<SalesByServicesModel> reportByServices = salesByServicesService.generateReport();
        model.addAttribute("reportByServices", reportByServices);
        return "admin/SalesByServicesPage";
    }

}
