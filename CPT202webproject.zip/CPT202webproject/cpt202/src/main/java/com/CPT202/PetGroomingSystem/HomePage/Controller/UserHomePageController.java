package com.CPT202.PetGroomingSystem.HomePage.Controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class UserHomePageController {
    @GetMapping("/user/userhome")
    public String getUserHome (Model model) {
        return "user/UserHomePage";
    }
}

