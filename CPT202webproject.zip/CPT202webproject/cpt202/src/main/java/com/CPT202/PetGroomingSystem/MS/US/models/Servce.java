package com.CPT202.PetGroomingSystem.MS.US.models;

import com.CPT202.PetGroomingSystem.MS.GF.models.Groomer;

import javax.persistence.*;
import java.util.List;

@Entity
public class Servce {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int id;
    private String name;
    private String info;
    private float price;

    @ManyToMany(mappedBy = "groomerProService", fetch = FetchType.EAGER)
    List<Groomer> groomers;

    public Servce() { }
    public Servce(int id, String name, String info, float price) {
        this.id = id;
        this.name = name;
        this.info = info;
        this.price = price;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getInfo() {
        return info;
    }

    public void setInfo(String info) {
        this.info = info;
    }

    public float getPrice() {
        return price;
    }

    public void setPrice(float price) {
        this.price = price;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<Groomer> getGroomers() {
        return groomers;
    }

    public void setGroomers(List<Groomer> groomers) {
        this.groomers = groomers;
    }

    @Override
    public String toString() {
        return name;
    }
}
