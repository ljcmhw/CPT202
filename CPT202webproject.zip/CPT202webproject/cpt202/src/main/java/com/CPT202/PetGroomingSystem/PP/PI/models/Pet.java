package com.CPT202.PetGroomingSystem.PP.PI.models;



import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Pet {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int id;
    private int UserID;

    private String petName;
    private String species;
    private String birthday;
    private Double weight;
    private boolean vaccinated;
    private boolean disabled;
    private int age;
    private String size;


//constructor
    public Pet(int id, String petName, String species, String birthday, Double weight, boolean vaccinated,
            boolean disabled, int age, String size) {
        this.id = id;
        this.petName = petName;
        this.species = species;
        this.birthday = birthday;
        this.weight = weight;
        this.vaccinated = vaccinated;
        this.disabled = disabled;
        this.age = age;
        this.size = size;
    }

    public Pet() {
    }
//getter and setter
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getPetName() {
        return petName;
    }

    public void setPetName(String petName) {
        this.petName = petName;
    }

    public String getSpecies() {
        return species;
    }

    public void setSpecies(String species) {
        this.species = species;
    }

    public String getBirthday() {
        return birthday;
    }

    public void setBirthday(String birthday) {
        this.birthday = birthday;
    }

    public Double getWeight() {
        return weight;
    }

    public void setWeight(Double weight) {
        this.weight = weight;
    }

    public boolean isVaccinated() {
        return vaccinated;
    }

    public void setVaccinated(boolean vaccinated) {
        this.vaccinated = vaccinated;
    }

    public boolean isDisabled() {
        return disabled;
    }

    public void setDisabled(boolean disabled) {
        this.disabled = disabled;
    }

    public int getUserID() {
        return UserID;
    }

    public void setUserID(int userID) {
        UserID = userID;
    }
    public String getSize() {
        return size;
    }

    public void setSize(String size) {
        this.size = size;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }
    
}
