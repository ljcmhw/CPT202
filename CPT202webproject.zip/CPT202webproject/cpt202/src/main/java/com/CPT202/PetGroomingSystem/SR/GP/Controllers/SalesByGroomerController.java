package com.CPT202.PetGroomingSystem.SR.GP.Controllers;

import com.CPT202.PetGroomingSystem.SR.GP.models.SalesReportByGroomerModel;
import com.CPT202.PetGroomingSystem.SR.GP.Services.SalesByGroomerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.List;

@Controller
@RequestMapping("/MaintainSalesReportPage")
public class SalesByGroomerController {
    @Autowired
    private SalesByGroomerService salesByGroomerService;

    @GetMapping("")
    public String getSalesReportPage() {
        return "admin/MaintainSalesReportPage";
    }

    @GetMapping("/byGroomer")
    public String getSalesReportByGroomer(Model model) {
        List<SalesReportByGroomerModel> reportByGroomer = salesByGroomerService.generateReport();
        model.addAttribute("reportByGroomer", reportByGroomer);
        return "admin/SalesByGroomerPage";
    }
}
