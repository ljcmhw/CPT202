package com.CPT202.PetGroomingSystem.SR.SP.Services;


import com.CPT202.PetGroomingSystem.MS.OD.Repo.OrderRepo;
import com.CPT202.PetGroomingSystem.MS.OD.models.OrderModel;
import com.CPT202.PetGroomingSystem.MS.US.Repo.ServceRepo;
import com.CPT202.PetGroomingSystem.SR.SP.models.SalesByServicesModel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;

@Service
public class SalesByServicesService {
    @Autowired
    private ServceRepo serviceRepo;

    @Autowired
    private OrderRepo orderRepo;

    public List<SalesByServicesModel> generateReport() {

        // 查询当天的订单列表
        String orderDateStr = LocalDate.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));
        List<OrderModel> orders = orderRepo.findByOrderDate(orderDateStr);
        Map<String, Integer> salesByService = new HashMap<>();

        for (OrderModel order : orders) {
            String[] services = order.getService().split(",");
            for (String serviceName : services) {
                int currentSalesCount = salesByService.getOrDefault(serviceName, 0);
                salesByService.put(serviceName, currentSalesCount + 1);
            }
        }

        List<SalesByServicesModel> report = new ArrayList<>();
        for (Map.Entry<String, Integer> entry : salesByService.entrySet()) {
            String serviceName = entry.getKey();
            int salesCount = entry.getValue();
            report.add(new SalesByServicesModel(serviceName, salesCount));

        }
        report.sort(Collections.reverseOrder());

        return report;
    }

}
