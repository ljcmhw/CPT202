package com.CPT202.PetGroomingSystem.SR.GP.Services;

import com.CPT202.PetGroomingSystem.MS.GF.Repo.GroomerRepo;
import com.CPT202.PetGroomingSystem.MS.OD.Repo.OrderRepo;
import com.CPT202.PetGroomingSystem.MS.OD.models.OrderModel;
import com.CPT202.PetGroomingSystem.SR.GP.models.SalesReportByGroomerModel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;

@Service

public class SalesByGroomerService {

        @Autowired
        private GroomerRepo groomerRepo;

        @Autowired
        private OrderRepo orderRepo;
    public List<SalesReportByGroomerModel> generateReport() {

        // 查询当天的订单列表
        String orderDateStr = LocalDate.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));
        List<OrderModel> orders = orderRepo.findByOrderDate(orderDateStr);
        Map<String, Integer> servicesByGroomer = new HashMap<>();

        for (OrderModel order : orders) {
            String groomerName = order.getGroomer();
            int servicesProvided = order.getService().split(",").length;
            int currentServicesCount = servicesByGroomer.getOrDefault(groomerName, 0);
            servicesByGroomer.put(groomerName, currentServicesCount + servicesProvided);
        }

        List<SalesReportByGroomerModel> report = new ArrayList<>();
        for (Map.Entry<String, Integer> entry : servicesByGroomer.entrySet()) {
            String groomerName = entry.getKey();
            int servicesProvided = entry.getValue();
            report.add(new SalesReportByGroomerModel(groomerName, servicesProvided));
        }
        return report;
    }

}
