package com.CPT202.PetGroomingSystem.PP.PI.Services;

import java.time.LocalDate;
import java.time.Period;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.CPT202.PetGroomingSystem.PP.PI.Repo.PetRepo;
import com.CPT202.PetGroomingSystem.PP.PI.models.Pet;
import com.CPT202.PetGroomingSystem.RL.Repo.UserRepo;


@Service
public class PetServices {
    @Autowired
    private PetRepo petRepo;
    
    @Autowired
    private UserRepo userRepo;
    public void birthToAge(Pet pet){
        LocalDate birth = LocalDate.parse(pet.getBirthday());
        LocalDate today = LocalDate.now();
        Period period = birth.until(today);
        int age = period.getYears();
        pet.setAge(age);
    }
    
    public Pet newPet(Pet pet){
        birthToAge(pet);
        WeightToSize(pet);
        return petRepo.save(pet);
    }
    public void updatePet(Pet pet) {
        petRepo.save(pet);
    }
    public List<Pet> getPetList(int userId){
        List<Pet> allPets = petRepo.findAll();
        List<Pet> userPets = new ArrayList<>();
        for (Pet pet : allPets) {
            if (pet.getUserID() == userId) {
                userPets.add(pet);
            }
        }
        return userPets;
    }
    public void deletePet(int id){
        petRepo.deleteById(id);
    };

    public Pet findByName(String name) {
        List<Pet> petList = petRepo.findAll();
        for (Pet i : petList) {
            if (Objects.equals(i.getPetName(), name)) return i;
        }
        return null;
    }
    
    public List<Pet> getListByName(List<String> names) {
        List<Pet> petList = new ArrayList<>();
        for (String name: names) {
            Pet pet = findByName(name);
            if (pet != null) petList.add(pet);
        }
        return petList;
    }

    public void WeightToSize(Pet pet){
        if(pet.getWeight()<=5){
            pet.setSize("little");
        }
        if(pet.getWeight()>5&&pet.getWeight()<=10){
            pet.setSize("medium");
        }
        if(pet.getWeight()>10){
            pet.setSize("big");
        }
    }
    
    public Optional<Pet> getPetById(int id){
        return petRepo.findById(id);
    }

    

    
}
