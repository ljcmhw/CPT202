package com.CPT202.PetGroomingSystem.MA.CS.Controllers;

import com.CPT202.PetGroomingSystem.MS.US.Services.DiscountService;
import com.CPT202.PetGroomingSystem.MS.US.Services.ServceService;
import com.CPT202.PetGroomingSystem.MS.US.models.Discount;
import com.CPT202.PetGroomingSystem.MS.US.models.Servce;
import com.fasterxml.jackson.databind.annotation.JsonAppend.Attr;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.CPT202.PetGroomingSystem.MA.CS.Services.MakeAppointmentService;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@Controller
@RequestMapping("/Service")
public class ChooseServicesController extends MArootController{
    @Autowired
    private MakeAppointmentService makeappointmentService;
    @Autowired
    private ServceService servceService;
    @Autowired DiscountService discountService;

    @GetMapping("/list")
    public String listServce(Model model){
        model.addAttribute("Discounts", makeappointmentService.getdiscountList());
        model.addAttribute("Services", makeappointmentService.getList());
        return "user/ListService";
    }
    
    @RequestMapping(value="/list",method=RequestMethod.POST)
    public String choosedservice(@RequestParam(value = "Discounts", required = false)String Discounts, @RequestParam(value="Services", required=false)String Services,Model model){
        List<String> allservicename = new ArrayList<>();
        if ((Services == null)&&(Discounts==null)) {
            model.addAttribute("ChoosedEmptyErr", "Please choose at least one service");
            return listServce(model);
        }
        if(Discounts!=null){
            List<String> disNames = new ArrayList<>(Arrays.asList(Discounts.split(",")));
            allservicename.addAll(disNames);
        }
        if(Services!=null){
            List<String> serNames = new ArrayList<>(Arrays.asList(Services.split(",")));
            allservicename.addAll(serNames);
        }
       
        
        List<Discount> disList = discountService.getListByInfo(allservicename);
        List<Servce> serList = servceService.getListByName(allservicename);
        
        return backMakeAppointment(model, null, disList, serList , null);
    }
}
