package com.CPT202.PetGroomingSystem.MS.CF.Services;

import com.CPT202.PetGroomingSystem.MS.CF.Repo.CustomerRepo;
import com.CPT202.PetGroomingSystem.MS.CF.models.Customer;
import com.CPT202.PetGroomingSystem.RL.Repo.UserRepo;
import com.CPT202.PetGroomingSystem.RL.models.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Objects;

@Service
public class CustomerService {
    @Autowired
    private UserRepo customerRepo;

    public User newCustomer(User c) {
        if (Objects.equals(c.getUserName(), "")
                || Objects.equals(c.getAddress(), "")
                || Objects.equals(c.getPhoneNumber(), "")
                || Objects.equals(c.getEmailAddress(), "")
                || Objects.equals(c.getPassword(),"")
        )
            return null;
        return customerRepo.save(c);
    }

    public List<User> getList() {

        return customerRepo.findCustomers();
    }
    public List<User> getDescList() {
        Sort sort = Sort.by(Sort.Direction.DESC, "id");
        return customerRepo.findAll(sort);
    }
    public void delCustomer(User c)
    {
        customerRepo.delete(c);
    }

    public User findById(int id) {
        //List<User> customers = userRepo.findCustomers();
        List<User> CustomerList = customerRepo.findAll();
        for (User i : CustomerList) {
            if (i.getId() == id) return i;
        }
        return null;
    }
}
