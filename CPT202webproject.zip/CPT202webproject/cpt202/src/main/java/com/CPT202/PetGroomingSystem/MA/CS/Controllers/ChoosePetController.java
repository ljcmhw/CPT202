package com.CPT202.PetGroomingSystem.MA.CS.Controllers;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.CPT202.PetGroomingSystem.PP.PI.Services.PetServices;
import com.CPT202.PetGroomingSystem.PP.PI.models.Pet;
import com.CPT202.PetGroomingSystem.RL.security.MyUserDetails;

@Controller
@RequestMapping("/pet")
public class ChoosePetController extends MArootController{
    @Autowired
    private PetServices petServices;

    @GetMapping("/List")
    public String Listpets(Model model){
        MyUserDetails userDetails = (MyUserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        int userId = userDetails.getId();
        List<Pet> userPetList = petServices.getPetList(userId); // 使用getUserPetList()方法来获取用户特定的宠物列表
        model.addAttribute("petList", userPetList); // 将宠物列表添加到Model对象中
        return "user/ListPets";
    }
    
    @RequestMapping(value="/List",method=RequestMethod.POST)
    public String choosedpet(@RequestParam(value="ChoosedPet", required=false)String ChoosedPet,Model model){
        if (ChoosedPet == null) {
            model.addAttribute("ChoosedEmptyErr", "Please choose at least one pet");
            return Listpets(model);
        }
        List<String> petNames = new ArrayList<>(Arrays.asList(ChoosedPet.split(",")));
        List<Pet> petList = petServices.getListByName(petNames);

        return backMakeAppointment(model, petList, null, null, null);
    }
}
