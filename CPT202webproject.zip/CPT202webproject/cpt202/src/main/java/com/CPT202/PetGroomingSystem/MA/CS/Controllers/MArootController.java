package com.CPT202.PetGroomingSystem.MA.CS.Controllers;

import com.CPT202.PetGroomingSystem.HomePage.Controller.rootController;
import com.CPT202.PetGroomingSystem.MS.GF.models.Groomer;
import com.CPT202.PetGroomingSystem.MS.OD.Services.OrderService;
import com.CPT202.PetGroomingSystem.MS.OD.models.OrderModel;
import com.CPT202.PetGroomingSystem.MS.US.models.Discount;
import com.CPT202.PetGroomingSystem.MS.US.models.Servce;
import com.CPT202.PetGroomingSystem.MS.US.models.Upselling;
import com.CPT202.PetGroomingSystem.PP.PI.models.Pet;
import com.CPT202.PetGroomingSystem.RL.models.User;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;


@Controller
public class MArootController extends rootController {
    static private List<Pet> petList;
    static private List<Discount> disList;
    static private List<Servce> serList;
    static private List<Groomer> groList;
    static private String dateStr="";
    static private String timeStr="";

 
    @Autowired
    private OrderService orderService;

    public String backMakeAppointment(Model model, List<Pet> petList, List<Discount> disList, List<Servce> serList, List<Groomer> groList) {
        if (petList != null) MArootController.petList = petList;
        if (disList != null) MArootController.disList = disList;
        if (serList != null) MArootController.serList = serList;
        if (groList != null) MArootController.groList = groList;
        model.addAttribute("choosedPet", MArootController.petList);
        model.addAttribute("chooseddiscount", MArootController.disList);
        model.addAttribute("choosedservice", MArootController.serList);
        model.addAttribute("choosedGroomer", MArootController.groList);
        model.addAttribute("dateStr", MArootController.dateStr);
        model.addAttribute("timeStr", MArootController.timeStr);
        return "user/MakeAppointmentPage";
    }

    public String SubmitOrder(User user,Model model,List<Pet> PetList,List<Discount> DisList, List<Servce> SerList,List<Groomer> GroList, List<Upselling> UpsList ,String time) throws ParseException{
        PetList = MArootController.petList;
        GroList = MArootController.groList;
        SerList = MArootController.serList;
        DisList = MArootController.disList;
        OrderModel order = new OrderModel();
        order.setCustomer(user.getUserName());
        order.setGroomer(groList.get(0).getGroomerName());
        order.setPet(petList.get(0).getPetName());
        order.setOrderstatus("Booked");
        SimpleDateFormat ft = new SimpleDateFormat("yyyy-MM-dd HH:mm");
        Date bookTime = ft.parse(time);
        order.setBooktime(bookTime);
        float extraprice = 0;
        if(UpsList==null){
            System.out.println("UpsList is null");
        }
        if(UpsList!=null){
            for(Upselling ups: UpsList){
                 extraprice+=ups.getPrice();
            }
        }
        if(DisList.isEmpty()){
            order.setService(serList.get(0).getName());
            order.setCost(serList.get(0).getPrice() + extraprice);
        }else{
            order.setService(disList.get(0).getInfo());
            order.setCost(disList.get(0).getPrice() + extraprice);
        }
        model.addAttribute("Order", orderService.newOrder(order));
        return loadHomePage(model);
    }

    public static List<Pet> getPetList() {
        return petList;
    }

    public static List<Groomer> getGroList() {
        return groList;
    }

    public static List<Servce> getSerList() {
        return serList;
    }
    public static List<Discount> getDisList() {
        return disList;
    }
    public static String getDateStr() {
        return dateStr;
    }
    public static void setDateStr(String dateStr) {
        MArootController.dateStr = dateStr;
    }
    public static String getTimeStr() {
        return timeStr;
    }
    public static void setTimeStr(String timeStr) {
        MArootController.timeStr = timeStr;
    }
}
