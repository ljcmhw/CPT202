package com.CPT202.PetGroomingSystem.RL.Services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.CPT202.PetGroomingSystem.RL.Repo.UserRepo;
import com.CPT202.PetGroomingSystem.RL.models.User;

@Service
public class UserRegistrationService {
    @Autowired
    private UserRepo userRepo;

    public User newUser (User user){
        return userRepo.save(user);
    }

}
