package com.CPT202.PetGroomingSystem.PP.OI.Controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.CPT202.PetGroomingSystem.HomePage.Controller.rootController;
import com.CPT202.PetGroomingSystem.PP.OI.Services.UserInfoService;
import com.CPT202.PetGroomingSystem.RL.models.User;

import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;


@Controller
@RequestMapping("/MaintainUserInfoPage")
public class UserInfoController extends rootController {
    @Autowired
    private UserInfoService userInfoService;
    
    @GetMapping("")
    public String getList(Model model) {
        model.addAttribute("UserInfoList", userInfoService.getSpecUser());
        return "user/MaintainUserInfoPage";
    }


    @RequestMapping(value="/edit/{id}", method=RequestMethod.GET)
    public String editUserInfo(@PathVariable String id, Model model) {
        User olduserInfo = userInfoService.findById(Integer.valueOf(id));
        model.addAttribute("olduserInfo", olduserInfo);
        return "user/EditUserInfo";
    }

    @PostMapping("/edit")
    public String updateUserInfo(@ModelAttribute("olduserInfo") User newuserInfo, Model model ){
        User u = userInfoService.newUserInfo(newuserInfo);
        if (u == null) {
            model.addAttribute("FieldEmptyErr", "Required field is empty, please fill in \n" +
                    "correct information");
            return "user/EditUserinfo";
        }
        return backMaintainUserInfoPage(model);
    }
    
}
