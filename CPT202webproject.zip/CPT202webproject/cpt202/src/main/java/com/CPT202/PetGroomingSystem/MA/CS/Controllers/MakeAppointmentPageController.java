package com.CPT202.PetGroomingSystem.MA.CS.Controllers;

import com.CPT202.PetGroomingSystem.MS.GF.models.Groomer;
import com.CPT202.PetGroomingSystem.MS.OD.Services.OrderService;
import com.CPT202.PetGroomingSystem.MS.US.models.Discount;
import com.CPT202.PetGroomingSystem.MS.US.models.Servce;
import com.CPT202.PetGroomingSystem.PP.PI.models.Pet;
import com.CPT202.PetGroomingSystem.RL.models.User;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import java.util.ArrayList;


@Controller
public class MakeAppointmentPageController extends MArootController{
    @Autowired
    private OrderService orderService;
    

    @GetMapping("/MakeAppointment")
    public String MakeAppointmentPage(Model model){
        return backMakeAppointment(model, new ArrayList<Pet>(), new ArrayList<Discount>(), new ArrayList<Servce>(), new ArrayList<Groomer>());
    }

    @PostMapping("/Pay")
    public String PaymentPage(@ModelAttribute("UserInformation") User user, Model model){
        return "user/PaymentPage";
    }
}
