package com.CPT202.PetGroomingSystem.MA.CT.Controllers;

import com.CPT202.PetGroomingSystem.MA.CS.Controllers.MArootController;
import com.CPT202.PetGroomingSystem.MA.CT.Services.AppointmentService;
import com.CPT202.PetGroomingSystem.MA.CT.models.Appointments;
import com.CPT202.PetGroomingSystem.MS.OD.Services.OrderService;
import com.CPT202.PetGroomingSystem.MS.OD.models.OrderModel;
import com.CPT202.PetGroomingSystem.MS.GF.models.Groomer;
import com.alibaba.fastjson2.JSON;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

@Controller
public class SelectDateController extends MArootController {

    @Autowired
    private OrderService orderService;

    @PostMapping("/dateSelected")
    public String selectDate(@ModelAttribute("dateStr")String dateStr, Model model) throws ParseException {
        SimpleDateFormat ft = new SimpleDateFormat("yyyy-MM-dd");
        Date date = ft.parse(dateStr);
        List<Groomer> groList = getGroList();
        List<OrderModel> appList = orderService.getList();
        List<String> timeList = new ArrayList<>();
        SimpleDateFormat formatter = new SimpleDateFormat("HH:mm");

        for (OrderModel app: appList) {
            LocalDate localDate = date.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
            LocalDate appDate = app.getBooktime().toInstant().atZone(ZoneId.systemDefault()).toLocalDate();

            if (localDate.compareTo(appDate) == 0) {
                for (Groomer gro: groList) {
                    if (Objects.equals(gro.getGroomerName(), app.getGroomer())) {
                        String timeString = formatter.format(app.getBooktime());
                        timeList.add(timeString);
                    }
                }
            }
        }

        //timeList.add("9:30");
        Map<String,String> timeMap = new HashMap<>();
        for(int i=0;i<timeList.size();i++){
            timeMap.put(timeList.get(i),timeList.get(i));
        }
        model.addAttribute("groTimeList", JSON.toJSONString(timeMap));
        return "user/MakeAppointmentPage";
    }
}
