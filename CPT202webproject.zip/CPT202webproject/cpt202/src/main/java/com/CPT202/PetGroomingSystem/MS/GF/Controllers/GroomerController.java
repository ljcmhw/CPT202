package com.CPT202.PetGroomingSystem.MS.GF.Controllers;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

// import javax.validation.Valid;

import com.CPT202.PetGroomingSystem.MS.US.Services.ServceService;
import com.CPT202.PetGroomingSystem.MS.US.models.Servce;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.Errors;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.CPT202.PetGroomingSystem.MS.GF.Services.GroomerService;
import com.CPT202.PetGroomingSystem.MS.GF.models.Groomer;

@Controller
@RequestMapping("/Groomer")
public class GroomerController extends GroRootController {
    @Autowired
    private GroomerService groomerService;
    @Autowired
    private ServceService servceService;

    @GetMapping("/add")
    public String addGroomer(Model model) {
        model.addAttribute("groomer", new Groomer());
        return "admin/AddGroomer";
    }

    @PostMapping("/add")
    public String confirmNewGroomer(@ModelAttribute("groomer") Groomer g,
                                    Model model) {
        List<String> serNamelst = List.of(g.getSerNameStr().split(","));
        List<Servce> serlst = servceService.getListByName(serNamelst);
        g.setGroomerProService(serlst);
        Groomer groomer = groomerService.newGroomer(g);
        if (groomer == null) {
            model.addAttribute("FieldEmptyErr", "Required field is empty, please fill in\n" + "correct information");
            return addGroomer(model);
        }
        return returnMaintainGroomerPage(model);
    }
    @RequestMapping(value = "/edit/{id}", method = RequestMethod.GET)
    public String editGroomer(@PathVariable String id, Model model) {
        Groomer oldGroomer = groomerService.findById(Integer.parseInt(id));
        model.addAttribute("oldGroomer", oldGroomer);
        return "admin/EditGroomer";
    }

    @PostMapping("/edit")
    public String updateGroomer(@ModelAttribute("oldGroomer") Groomer newInfo,
                                Model model) {
        List<String> serNamelst = List.of(newInfo.getSerNameStr().split(","));
        List<Servce> serlst = servceService.getListByName(serNamelst);
        newInfo.setGroomerProService(serlst);
        Groomer updatedInfo = groomerService.newGroomer(newInfo);
        if (updatedInfo == null) {
            model.addAttribute("FieldEmptyErr", "Required field is empty, please fill in \n" +
                    "correct information");
            return "admin/EditGroomer";
        }
        return returnMaintainGroomerPage(model);
    }

    @GetMapping("/delete/{id}")
    public String deleteGroomer(@PathVariable("id") Integer id, Model model) {

        groomerService.delGroomerById(id);

        return returnMaintainGroomerPage(model);
    }
}

    
