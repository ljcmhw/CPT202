package com.CPT202.PetGroomingSystem.RL.Repo;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.CPT202.PetGroomingSystem.RL.models.User;
import org.springframework.data.jpa.repository.Query;


public interface UserRepo extends JpaRepository<User, Integer>{
    Optional<User> findByUserNameOrEmailAddress(String userName,String emailAddress);
    Optional<User> findById(int id);

    @Query("SELECT u FROM User u WHERE u.roles = 'Customer'")
    List<User> findCustomers();


}