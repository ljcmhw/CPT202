package com.CPT202.PetGroomingSystem.MS.OD.Repo;
import org.springframework.data.jpa.repository.JpaRepository;

import com.CPT202.PetGroomingSystem.MS.OD.models.OrderModel;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.LocalDate;
import java.util.List;

public interface OrderRepo extends JpaRepository<OrderModel, Integer> {
    @Query("SELECT o FROM OrderModel o WHERE DATE_FORMAT(o.dateTimeStr, '%Y-%m-%d') = :orderDate")
    List<OrderModel> findByOrderDate(@Param("orderDate") String orderDate);
    @Query("SELECT o FROM OrderModel o WHERE (:status is null or o.orderstatus = :status) and (:customer is null or o.customer = :customer) ORDER BY o.booktime DESC")
    List<OrderModel> findByStatusAndCustomer(@Param("status") String status, @Param("customer") String customer);

}

