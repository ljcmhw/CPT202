package com.CPT202.PetGroomingSystem.MA.CS.Controllers;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.CPT202.PetGroomingSystem.MS.US.models.Servce;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.CPT202.PetGroomingSystem.MS.GF.Services.GroomerService;
import com.CPT202.PetGroomingSystem.MS.GF.models.Groomer;

@Controller
@RequestMapping("/AvailableGroomers")
public class ChooseGroomerController extends MArootController{
    @Autowired
    private GroomerService groomerService;


    @GetMapping("/list")
    public String listGroomer(Model model) {
        List<Servce> serlst = getSerList();
        List<Groomer> grolst = new ArrayList<>();
        for (Servce ser: serlst) {
            for (Groomer gro: ser.getGroomers()) {
                if (!grolst.contains(gro))
                    grolst.add(gro);
            }
        }
        model.addAttribute("Groomers", grolst);
        return "user/ListRelevantGroomer";
    }

    @RequestMapping(value="/list",method=RequestMethod.POST)
    public String choosedgroomer(@RequestParam(value="Groomers", required=false)String Groomers,Model model){
        if (Groomers == null) {
            model.addAttribute("ChoosedEmptyErr", "Please choose at least one groomer or select Allocate any groomer");
            return listGroomer(model);
        }
        else if (getSerList() == null || getSerList().isEmpty()) {
            model.addAttribute("OrderErr", "Please choose service first");
            return listGroomer(model);
        }
        List<String> groNames = new ArrayList<>(Arrays.asList(Groomers.split(",")));
        List<Groomer> groList = groomerService.getListByName(groNames);
        return backMakeAppointment(model, null, null, null, groList);
    }

    @RequestMapping(value="/anygroomer",method=RequestMethod.POST)
    public String allocateanygroomer(Model model){
        if (getSerList() == null || getSerList().isEmpty()) {
            model.addAttribute("OrderErr", "Please choose service first");
            return listGroomer(model);
        }
        List<Groomer> alloList = new ArrayList<>();
        List<Groomer> groList = groomerService.getSortByName();
        alloList.add(groList.get(0)); //固定选取groomer数据库中的第三个
        return backMakeAppointment(model, null, null, null, alloList);
    }
}