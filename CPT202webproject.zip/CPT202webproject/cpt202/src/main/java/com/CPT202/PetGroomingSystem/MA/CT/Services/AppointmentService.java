package com.CPT202.PetGroomingSystem.MA.CT.Services;

import com.CPT202.PetGroomingSystem.MA.CT.Repo.AppointmentRepo;
import com.CPT202.PetGroomingSystem.MA.CT.models.Appointments;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AppointmentService {
    @Autowired
    AppointmentRepo appointmentRepo;

    public List<Appointments> getList() {
        return appointmentRepo.findAll();
    }

    public Appointments addNew(Appointments app) {
        return appointmentRepo.save(app);
    }
}
