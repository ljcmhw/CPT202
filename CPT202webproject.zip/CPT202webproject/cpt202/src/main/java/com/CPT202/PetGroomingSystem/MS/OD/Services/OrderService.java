package com.CPT202.PetGroomingSystem.MS.OD.Services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.stereotype.Service;

import com.CPT202.PetGroomingSystem.MS.OD.models.OrderModel;
import com.CPT202.PetGroomingSystem.MS.OD.Repo.OrderRepo;

import org.springframework.data.domain.Sort;

import java.util.List;

@Service //OrderService是一个Spring Bean，用于在服务层中处理订单相关的业务逻辑
public class OrderService {
    @Autowired //自动注入OrderRepo类型的对象，用于操作数据库
    private OrderRepo orderRepo;

    public OrderModel newOrder(OrderModel order) {
        return orderRepo.save(order);
    }

    public List<OrderModel> getList() {
        return orderRepo.findAll();
    }
    
    //get order list by order status
    public List<OrderModel> getOrderList(String status, String customer) {
        if ("All".equals(status)){
            status = null;
        }
        return orderRepo.findByStatusAndCustomer(status, customer);
    }
     //status==All, show all orders
        // if (("All".equals(status))&&(customer == null)) {
        //     // return orderRepo.findAll();
        //     return orderRepo.findAll(Sort.by(Sort.Direction.DESC, "booktime"));
        // }else if (("All".equals(status))&&(customer != null)) {
        //     OrderModel or = new OrderModel();
        //     or.setCustomer(customer);
        //     Example<OrderModel> example = Example.of(or);//Example对象是Spring Data JPA提供的一种用于进行查询的辅助类，它可以通过设置查询实体的属性值来生成一个查询条件
        //     return orderRepo.findAll(example, Sort.by(Sort.Direction.DESC, "booktime"));
        // }else if ((!"All".equals(status))&&(customer == null)) {
        //     OrderModel or = new OrderModel();
        //     or.setOrderstatus(status);
        //     Example<OrderModel> example = Example.of(or);
        //     return orderRepo.findAll(example, Sort.by(Sort.Direction.DESC, "booktime"));
        // }else{
        //     OrderModel or = new OrderModel();
        //     or.setOrderstatus(status);
        //     or.setCustomer(customer);
        //     Example<OrderModel> example = Example.of(or);  
        //     return orderRepo.findAll(example, Sort.by(Sort.Direction.DESC, "booktime"));
        // }   

    //update order status
    public void updateStatus(int id, String status) {
        //search order by id
        OrderModel one = orderRepo.findById(id).orElse(null); 
        if (one != null) { 
            one.setOrderstatus(status); 
            orderRepo.save(one); 
        }
    }

    //cancel uncompleted order
    public void cancel(int id) {
        orderRepo.deleteById(id);
    }
}

