package com.CPT202.PetGroomingSystem.PP.OI.Services;

import java.util.List;
import java.util.Objects;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import com.CPT202.PetGroomingSystem.RL.Repo.UserRepo;
import com.CPT202.PetGroomingSystem.RL.models.User;
import org.springframework.data.domain.Sort;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;

@Service
public class UserInfoService {
    @Autowired
    UserRepo userrepo;
    public User newUserInfo(User user){
//         if (Objects.equals(user.getUserName(), "") || Objects.equals(user.getEmailAddress(), "") || Objects.equals(user.getPhoneNumber(), "") || Objects.equals(user.getPassword(), "") || Objects.equals(user.getAddress(), "") 
// )
//         return null;

        return userrepo.save(user);
    }

    public List<User> getDescList() {
        Sort sort = Sort.by(Sort.Direction.DESC, "id");
        return userrepo.findAll(sort);
    }

    public List<User> getList(){
        return userrepo.findAll();
    }

    public User findById(int id){
        List<User> UserInfoList = userrepo.findAll();
        for(User i : UserInfoList){
            if (i.getId() == id) return i;
        }
        return null;
    }

    public Optional<User> getSpecUser(){
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        Optional<User> returneduser = userrepo.findByUserNameOrEmailAddress(authentication.getName(), authentication.getName());
        return returneduser;
    }

}
