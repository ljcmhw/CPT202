package com.CPT202.PetGroomingSystem.MA.CT.models;

import com.CPT202.PetGroomingSystem.MS.GF.models.Groomer;
import org.springframework.format.annotation.DateTimeFormat;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import java.util.Date;

@Entity
public class Appointments {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int id;

    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm")
    private Date time;
    private String gro;

    public Appointments() { }
    public Appointments(int id, Date time, String gro) {
        this.id = id;
        this.time = time;
        this.gro = gro;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getId() {
        return id;
    }

    public Date getTime() {
        return time;
    }

    public String getGro() {
        return gro;
    }

    public void setGro(String gro) {
        this.gro = gro;
    }

    public void setTime(Date time) {
        this.time = time;
    }
}
