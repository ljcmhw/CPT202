package com.CPT202.PetGroomingSystem.HomePage.Controller;

import com.CPT202.PetGroomingSystem.MS.CF.Services.CustomerService;
import com.CPT202.PetGroomingSystem.MS.OD.Services.OrderService;
import com.CPT202.PetGroomingSystem.MS.US.Services.DiscountService;
import com.CPT202.PetGroomingSystem.MS.US.Services.ServceService;
import com.CPT202.PetGroomingSystem.MS.US.Services.UpsellingService;
import com.CPT202.PetGroomingSystem.PP.OI.Services.UserInfoService;
import com.CPT202.PetGroomingSystem.RL.models.User;
import com.CPT202.PetGroomingSystem.RL.Repo.UserRepo;
import com.CPT202.PetGroomingSystem.RL.security.MyUserDetails;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;

@Controller
public class rootController {
    @Autowired
    private UpsellingService upsellingService;
    @Autowired
    private DiscountService discountService;
    @Autowired
    private ServceService servceService;
    @Autowired
    private CustomerService customerService;
    @Autowired
    private UserInfoService userInfoService;
    @Autowired
    private UserRepo userRepo;
    @Autowired
    private OrderService orderService;

    public String backMaintainPage(Model model) {
        model.addAttribute("DiscountList", discountService.getDescList());
        model.addAttribute("UpsellList", upsellingService.getDescList());
        model.addAttribute("ServceList", servceService.getDescList());
        return "admin/MaintainServicesPage";
    }

    public String backMaintainCustomerPage(Model model) {
        model.addAttribute("CustomerList", customerService.getDescList());
        return "admin/MaintainCustomersPage";
    }

    public String backMaintainUserInfoPage(Model model){
        model.addAttribute("UserInfoList",userInfoService.getSpecUser() );
        return "user/MaintainUserInfoPage";
    }

    public String loadHomePage(Model model) {
        try{
        MyUserDetails userDetails = (MyUserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Optional<User> returneduser = userRepo.findById(userDetails.getId());
        User user = returneduser.orElseThrow(() -> new UsernameNotFoundException("User not found"));
        if(user.getRoles().equals("fhX2jlltyz")){
            return "admin/AdminHomePage";
        }
        }catch(Exception e){}
        
        model.addAttribute("DiscountList", discountService.getDescList());
        model.addAttribute("UpsellList", upsellingService.getDescList());
        model.addAttribute("ServceList", servceService.getDescList());
        model.addAttribute("CustomerList", customerService.getDescList());
        model.addAttribute("Order", orderService.getList());
        return "HomePage";
    }
}
