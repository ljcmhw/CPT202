package com.CPT202.PetGroomingSystem.SR.SP.Repo;

import com.CPT202.PetGroomingSystem.SR.SP.models.SalesByServicesModel;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SalesByServicesRepo extends JpaRepository<SalesByServicesModel, Integer> {

}
