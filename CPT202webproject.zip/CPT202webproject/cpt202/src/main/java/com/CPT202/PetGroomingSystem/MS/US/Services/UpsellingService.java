package com.CPT202.PetGroomingSystem.MS.US.Services;

import com.CPT202.PetGroomingSystem.MS.US.Controllers.UpsellingController;
import com.CPT202.PetGroomingSystem.MS.US.Repo.UpsellingRepo;
import com.CPT202.PetGroomingSystem.MS.US.models.Discount;
import com.CPT202.PetGroomingSystem.MS.US.models.Upselling;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Objects;
import java.util.ArrayList;
import java.util.Date;

@Service
public class UpsellingService {
    @Autowired
    private UpsellingRepo upsellingRepo;

    private List<Upselling> checkDate(List<Upselling> lst) {
        Date curDate = new Date();
        for (Upselling i : lst) {
            if (i.getTimelmt().compareTo(curDate) < 0) {
                upsellingRepo.deleteById(i.getId());
            }
        }
        lst = upsellingRepo.findAll();
        return lst;
    }

    public Upselling newUpselling(Upselling s) {
        if (Objects.equals(s.getCond(), "") || Objects.equals(s.getInfo(), "") || Objects.equals(s.getCont(), ""))
            return null;
        Date curDate = new Date();
        if (s.getTimelmt().compareTo(curDate) <= 0) return null;
        return upsellingRepo.save(s);
    }

    public List<Upselling> getList() {
        List<Upselling> lst = upsellingRepo.findAll();
        return checkDate(lst);
    }
    public List<Upselling> getDescList() {
        Sort sort = Sort.by(Sort.Direction.DESC, "id");
        List<Upselling> lst = upsellingRepo.findAll();
        return checkDate(lst);
    }

    public void delUpselling(Upselling s) {
        upsellingRepo.delete(s);
    }
    public Upselling findById(int id) {
        List<Upselling> UpList = upsellingRepo.findAll();
        for (Upselling i : UpList) {
            if (i.getId() == id) return i;
        }
        return null;
    }
    public Upselling findByInfo(String info) {
        List<Upselling> upsellingList = upsellingRepo.findAll();
        for (Upselling i : upsellingList) {
            if (Objects.equals(i.getInfo(), info)) return i;
        }
        return null;
    }
    public List<Upselling> getListByInfo(List<String> info) {
        List<Upselling> upsellingList = new ArrayList<>();
        for (String inform: info) {
            Upselling ups = findByInfo(inform);
            if (ups != null) upsellingList.add(ups);
        }
        return upsellingList;
    }
}
