package com.CPT202.PetGroomingSystem.RL.config;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.CPT202.PetGroomingSystem.RL.Repo.UserRepo;
import com.CPT202.PetGroomingSystem.RL.models.User;
import com.CPT202.PetGroomingSystem.RL.security.MyUserDetails;

@Service
public class MyUserDetailService implements UserDetailsService{
    @Autowired
    private UserRepo userRepo;

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException{
        Optional<User> returneduser = userRepo.findByUserNameOrEmailAddress(username,username);
        try {
            User user = returneduser.orElseThrow(() -> new UsernameNotFoundException("User not found"));
            return new MyUserDetails(user);
        } catch (Exception e) {
            return  new MyUserDetails(new User());
        }
       
    }

    


}
