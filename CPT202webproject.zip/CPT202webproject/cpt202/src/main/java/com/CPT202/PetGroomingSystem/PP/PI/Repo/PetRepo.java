package com.CPT202.PetGroomingSystem.PP.PI.Repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.CPT202.PetGroomingSystem.PP.PI.models.Pet;



public interface PetRepo extends JpaRepository<Pet, Integer>{
    
}
