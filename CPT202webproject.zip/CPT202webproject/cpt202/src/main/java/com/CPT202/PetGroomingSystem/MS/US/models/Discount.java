package com.CPT202.PetGroomingSystem.MS.US.models;

import com.fasterxml.jackson.annotation.JsonFormat;
import org.springframework.format.annotation.DateTimeFormat;

import javax.persistence.*;
import java.util.Date;

@Entity
public class Discount {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int id;
    private String info;
    private String cond;
    private float price;

    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date timelmt;

    public Discount() { }
    public Discount(int id, String info, String cond, float price, Date timelmt) {
        this.id = id;
        this.info = info;
        this.cond = cond;
        this.price = price;
        this.timelmt = timelmt;
    }

    public float getPrice() { return this.price; }
    public void setPrice(float price) { this.price = price; }
    public int getId() { return this.id; }

    public void setId(int id) {
        this.id = id;
    }

    public Date getTimelmt() {
        return timelmt;
    }

    public String getCond() {
        return cond;
    }

    public String getInfo() {
        return info;
    }

    public void setCond(String cond) {
        this.cond = cond;
    }

    public void setInfo(String info) {
        this.info = info;
    }

    public void setTimelmt(Date timelmt) {
        this.timelmt = timelmt;
    }
}
