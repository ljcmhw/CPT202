package com.CPT202.PetGroomingSystem.SR.GP.Repo;

import com.CPT202.PetGroomingSystem.SR.GP.models.SalesReportByGroomerModel;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SalesByGroomerRepo extends JpaRepository<SalesReportByGroomerModel, Integer> {

}
