package com.CPT202.PetGroomingSystem.MS.GF.models;

import com.CPT202.PetGroomingSystem.MS.US.models.Servce;
import org.springframework.format.annotation.DateTimeFormat;

import javax.persistence.*;
import java.util.Date;
import java.util.List;
// import org.hibernate.validator.constraints.Range;

@Entity
@Table(name = "groomer")
public class Groomer {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int id;

    //unique name
    //@Column(name="CustomerName", unique = true)
    private String groomerName;
    private String phoneNumber;
    private String email;

    @DateTimeFormat(pattern = "HH:mm")
    private Date officeHourStart;

    @DateTimeFormat(pattern = "HH:mm")
    private Date officeHourEnd;

    // @Range(min=3, max=5, message = "Invalid Ranking input. Ranking should between 3 and 5.")
    private int ranking;

    private String serNameStr;
    @ManyToMany(fetch = FetchType.EAGER)
    @JoinTable(
            name = "gro_sev",
            joinColumns = @JoinColumn(name = "gro_id"),
            inverseJoinColumns = @JoinColumn(name = "sev_id")
    )
    private List<Servce> groomerProService; //service provided by groomer

    
    public Groomer(int id, String groomerName, String phoneNumber, String email,
                   Date officeHourStart, Date officeHourEnd, int ranking,
                   List<Servce> groomerProService) {
        this.id = id;
        this.groomerName = groomerName;
        this.phoneNumber = phoneNumber;
        this.email = email;
        this.officeHourStart = officeHourStart;
        this.officeHourEnd = officeHourEnd;
        this.ranking = ranking;
        this.groomerProService = groomerProService;
    }

    public Groomer() { }

    public int getId() {
        return id;
    }

    public Date getOfficeHourEnd() {
        return officeHourEnd;
    }

    public Date getOfficeHourStart() {
        return officeHourStart;
    }

    public void setOfficeHourEnd(Date officeHourEnd) {
        this.officeHourEnd = officeHourEnd;
    }

    public void setOfficeHourStart(Date officeHourStart) {
        this.officeHourStart = officeHourStart;
    }

    public void setId(int id) {
        this.id = id;
    }
    
    public String getGroomerName() {
        return groomerName;
    }
    public void setGroomerName(String groomerName) {
        this.groomerName = groomerName;
    }
    public String getPhoneNumber() {
        return phoneNumber;
    }
    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }
    public String getEmail() {
        return email;
    }
    public void setEmail(String email) {
        this.email = email;
    }
    public int getRanking() {
        return ranking;
    }
    public void setRanking(int ranking) {
        this.ranking = ranking;
    }
   
    public List<Servce> getGroomerProService() {
        return groomerProService;
    }

    public void setGroomerProService(List<Servce> groomerProService) {
        this.groomerProService = groomerProService;
    }

    public String getSerNameStr() {
        return serNameStr;
    }

    public void setSerNameStr(String serNameStr) {
        this.serNameStr = serNameStr;
    }
}
