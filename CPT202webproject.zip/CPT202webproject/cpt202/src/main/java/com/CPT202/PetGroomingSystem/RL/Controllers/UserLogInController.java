package com.CPT202.PetGroomingSystem.RL.Controllers;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.CPT202.PetGroomingSystem.PP.OI.Services.UserInfoService;
import com.CPT202.PetGroomingSystem.PP.PI.Services.PetServices;
import com.CPT202.PetGroomingSystem.RL.Repo.UserRepo;
import com.CPT202.PetGroomingSystem.RL.Services.UserLogInService;
import com.CPT202.PetGroomingSystem.RL.Services.UserRegistrationService;
import com.CPT202.PetGroomingSystem.RL.models.User;
import com.CPT202.PetGroomingSystem.RL.security.MyUserDetails;

@Controller
@RequestMapping("/user")
public class UserLogInController {
    static String ENCRYPTEDKEY="fhX2jlltyz";
    @Autowired
    private UserLogInService userLogInService;
    @Autowired
    private UserRegistrationService userRegistrationService;
    @Autowired
    private UserRepo userRepo;
    @Autowired
    private UserInfoService userInfoService;
    @Autowired
    private PetServices petService;


    @GetMapping("")
    public String userPage(){
        return "UserPage";
    }

    @PostMapping("/login")
    public String logIn(){
        return "LogIn";
    }

    @GetMapping("/login")
    public String logInRegistration(Model model){
        model.addAttribute("User", new User());
        return "LogIn";
    }

    @GetMapping("/login/success")
    public String logInSuccess(){
        return "LogInSuccess";
    }

    @GetMapping("/login/failure")
    public String logInFailure(){
        return "LogInFailure";
    }


    @GetMapping("/registration")
    public String registration(Model model){
        model.addAttribute("User", new User());
        return "Registration";
    }
    
    @PostMapping("/registration")
    public String userRegistration(@ModelAttribute("User") User user, Model model){
        if(user.getUserName().equals("")||user.getPassword().equals("")||user.getEmailAddress().equals("")||user.getPhoneNumber().equals("")||user.getAddress().equals("")){
            model.addAttribute("NotFilled", "Required fields are not all filled. Please fill them.");
            return "Registration";
        }
        if(!user.getRoles().equals(ENCRYPTEDKEY))
            user.setRoles("Customer");
        user.setActive(true);
        userRegistrationService.newUser(user);
        model.addAttribute("User", user);
        return "LogIn";
    }

    @GetMapping("/information")
    public String userInformation(Model model){
        try{
        MyUserDetails userDetails = (MyUserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Optional<User> returneduser = userRepo.findById(userDetails.getId());
            User user = returneduser.orElseThrow(() -> new UsernameNotFoundException("User not found"));
            model.addAttribute("UserInformation", user);
        }catch(Exception e){
            model.addAttribute("UserInformation", new User());
        }
        return "UserInformation";
    }

    @GetMapping("/information/modify")
    public String modifyUserInformation(Model model){
        try{
            MyUserDetails userDetails = (MyUserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
            Optional<User> returneduser = userRepo.findById(userDetails.getId());
            User user = returneduser.orElseThrow(() -> new UsernameNotFoundException("User not found"));
            model.addAttribute("UserInformation", user);
        }catch(UsernameNotFoundException e){
            model.addAttribute("UserInformation", new User());
        }
        return "ModifyUserInformation";
    }

    @PostMapping("/information")
    public String saveUserInformation(@ModelAttribute("UserInformation") User user, Model model){
        MyUserDetails userDetails = (MyUserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        user.setId(userDetails.getId());
        if (!user.getRoles().equals(ENCRYPTEDKEY)) user.setRoles("Customer");
        user.setActive(true);
        userRepo.save(user);
        
        return "UserInformation";
    }
}

