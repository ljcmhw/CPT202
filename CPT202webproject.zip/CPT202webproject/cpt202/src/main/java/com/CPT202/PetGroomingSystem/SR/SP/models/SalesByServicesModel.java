package com.CPT202.PetGroomingSystem.SR.SP.models;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity

public class SalesByServicesModel {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    private String serviceName;

    private int totalSales;

    public SalesByServicesModel() {
    }

    public SalesByServicesModel(Integer id, String serviceName, int totalSales) {
        this.id = id;
        this.serviceName = serviceName;
        this.totalSales = totalSales;
    }
    public SalesByServicesModel(String serviceName, int totalSales) {
        this.serviceName = serviceName;
        this.totalSales = totalSales;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getServiceName() {
        return serviceName;
    }

    public void setServiceName(String serviceName) {
        this.serviceName = serviceName;
    }

    public int getTotalSales() {
        return totalSales;
    }

    public void setTotalSales(int totalSales) {
        this.totalSales = totalSales;
    }

}