package com.CPT202.PetGroomingSystem.MA.CS.Services;

import java.util.List;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.CPT202.PetGroomingSystem.MS.US.Repo.DiscountRepo;
import com.CPT202.PetGroomingSystem.MS.US.Repo.ServceRepo;
import com.CPT202.PetGroomingSystem.MS.US.Repo.UpsellingRepo;
import com.CPT202.PetGroomingSystem.MS.US.models.Discount;
import com.CPT202.PetGroomingSystem.MS.US.models.Servce;
import com.CPT202.PetGroomingSystem.MS.US.models.Upselling;

import org.springframework.data.domain.Sort;

@Service
public class MakeAppointmentService {
    @Autowired
    private ServceRepo serviceRepo;
    @Autowired
    private DiscountRepo discountRepo;
    @Autowired
    private UpsellingRepo upsellingRepo;

    public Servce newService(Servce s) {
        if (Objects.equals(s.getName(), "") || Objects.equals(s.getInfo(), "") || s.getPrice() == 0) {
            return null;
        }
        return serviceRepo.save(s);
    }

    public List<Servce> getList() { 
        Sort sort = Sort.by(Sort.Direction.ASC, "name");
        return serviceRepo.findAll(sort); 
    }

    public List<Discount> getdiscountList(){
        Sort sort = Sort.by(Sort.Direction.ASC, "info");
        return discountRepo.findAll(sort);
    }

    public List<Upselling> getupsellingList(){
        Sort sort = Sort.by(Sort.Direction.ASC, "info");
        return upsellingRepo.findAll(sort);
       }
}
