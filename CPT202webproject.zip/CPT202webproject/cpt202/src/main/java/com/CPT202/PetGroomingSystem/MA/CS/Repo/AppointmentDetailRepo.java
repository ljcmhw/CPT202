package com.CPT202.PetGroomingSystem.MA.CS.Repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.CPT202.PetGroomingSystem.MA.CS.models.AppointmentDetail;

public interface AppointmentDetailRepo extends JpaRepository<AppointmentDetail, Integer>{
    
}
