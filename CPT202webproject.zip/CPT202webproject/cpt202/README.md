# CPT202
_大家好，我是傻逼杨子川_

## 1. 如何使用
### 关于 GitLab
idea 选手参考这篇[文章](https://blog.csdn.net/qq_41806718/article/details/106333053)使用 GitLab 插件
### 关于 MySQL
_建议：请新建一个名为 `cpt202` 的数据库，用户名为 `root`，密码为 `password`（参考 application.properties 文件）_

对于数据库的建立，请使用自定义密码。但是创建数据库后在执行代码之前请在 `./resources/application.properties` 中修改 `spring.datasource.password` 为你设置的密码，并在最终 merge branch 之前在 `.gitignore` 里添加 `application.properties` 的文件地址。[参考文章](https://blog.csdn.net/qq_41437512/article/details/128570511)

如果使用 MySQL 时出现连接不到 localhost 的情况，请参考这篇[文章](https://blog.csdn.net/epyingxue/article/details/86085942)

## 2. 使用时注意
现在有两个分支 `main` 和 `master`，我们项目的主分支是 `main`，不要往 `master` 分支合并。在最后要把 `master` 分支删掉的。

## 3. 一些文件
- `/main/templates` 下创建了两个文件夹 `/admin`、`/user`，分别用来放 **只有管理员或者只有客户能看见的页面** ，管理员和客户都能看见的页面直接放在 `/templates` 目录下。跳转该网页时可以通过如下方式：
    ```java
    // 例如要跳转到 /user/page.html 这个网页
    @GetMapping("/page")
    public String MaintainPage() {
        return "user/page";
    }
    ```
- home page 分了两个：`HomePage.html` 和 `/admin/AdminHomePage.html`，因为管理员的主页应该会和普通用户的不一样（大概
- java 文件的存放路径按 pbi 编号来创建，如杨子川的第一个 pbi 是 `MSUS01`，则路径为 `/java/com.CPT202.PetGroomingSystem/MS/US/`
- 在 `/static` 文件夹下新建了两个文件夹 `/CSS` 和 `/JS` 来存放相关文件。文件调用方法如下：
    - css 文件：在 `<head></head>` 标签中间加入 `<link rel="stylesheet" type="text/css" th:href="@{/CSS/yourFile.css}">`
    - javaScript 文件：在 `</body>` 标签后面加入 `<script type="text/javascript" th:src="@{/JS/yourFile.js}"></script>`
- 所有 service 的名称请以大写字母开头（指给宠物提供的具体服务）。
- _建议：所有管理员看到的内容以编号（ID）排序，而用户所见以首字母顺序排序。_


大家也可以把自己创建了什么文件夹、用来做什么都往这里写一下，省的乱 :)

# 更新日志
## 何子扬
### 2023.04.15
完善了登录及注册，还未实现注册未填信息高亮和注册完成重定向至登录界面自动填写用户名和密码

### 2023.04.13
今天初步实现了登录，目前不知道如何查看登录信息。
还未解决如果数据库没有对应登录的username会网站报错。
关于管理者能看到额外的界面需要和他人确定。
如需使用登录操作，pom.xml中security请不要注释。

### 2023.04.07
Groomer model 中的 GroomerName 改为 groomerName, groomerService 改成 groomerProService用于避免与Service class造成混淆。
edit可以用，但会创建新链接。建议注释掉。
GroomerFile的HTML还在GroomerFile文件夹里，忘记改了。

### 2023.04.05
增加了Groomer ranking & service provided by groomer. 
Ranking 没加限制，service没有从service repo中读取。
Maintain Groomer page 一加 edit 链接就跑不了。已comment。

### 2023.04.04
GF文件用于管理Groomer file。
目前可以实现增加groomer。groomer的各种属性（名字、邮箱、电话）未经过验证，availability目前还只是string，没有时间的格式。

修改groomer暂时不能用。delete也没法用。

maintain groomer page可显示groomer信息，但groomer顺序目前没有按字母顺序排列。

Admin Home Page 增加了"前往 maintain groomer page“的链接。

## jsc
### MSOD 管理员维护订单列表
- 未完成：读取choose数据库
      

## LJC的一些Tips：
### 目前MA页面可以返回Homepage，但后者不能到达前者。

### Choose service, Choose/Allocate groomer 全流程记录：
- Choose service: 将admin录入的服务信息直接调取并显示在选择服务界面，通过复选框的方式返回用户选择的服务名称。将名称和id存入一个新的数据库中并命名为ChoosedService。将该数据库展现在MA页面上，并在每次刷新以后清空该数据库。
- Choose groomer：首先获取admin录入groomer信息的数据库GRoomer，紧接着根据用户已经选择的服务名称对GRoomer里的groomer进行筛选，将对应该服务的groomer存入一个新的数据库RelevantGroomer中。在选择groomer界面将RelevantGroomer展示出来并根据它制作复选框。复选框返回的内容存入另一个新数据库ChoosedGroomer并展示到MA页面。每次刷新后清空RelevantGroomer和ChoosedGroomer数据库。
- Allocate any groomer：伪随机，暂定固定返回RelevantGroomer表格中的第三条数据。
